package pl.stp94.truckforwarder;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TruckforwarderApplicationTests {

    @Test
    void contextLoads() {
    }

}
