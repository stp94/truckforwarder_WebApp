package pl.stp94.truckforwarder.models.player;

import pl.stp94.truckforwarder.interfaces.ITruck;
import pl.stp94.truckforwarder.models.actions.BuyTruck;
import pl.stp94.truckforwarder.models.market.TrucksMarket;

import java.util.ArrayList;
import java.util.List;

public class FreeTrucks {

    List<ITruck> FreeTrucksList = new ArrayList<>();




}
