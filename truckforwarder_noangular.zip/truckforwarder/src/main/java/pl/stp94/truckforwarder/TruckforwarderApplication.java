package pl.stp94.truckforwarder;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TruckforwarderApplication {

    public static void main(String[] args) {
        SpringApplication.run(TruckforwarderApplication.class, args);
    }

}
