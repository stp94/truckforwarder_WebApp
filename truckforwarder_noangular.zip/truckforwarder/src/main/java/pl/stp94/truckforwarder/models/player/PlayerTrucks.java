package pl.stp94.truckforwarder.models.player;

public class PlayerTrucks {
}
