package pl.stp94.truckforwarder.api.trucks;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import pl.stp94.truckforwarder.interfaces.ITruck;
import pl.stp94.truckforwarder.models.market.TrucksMarket;

import java.util.ArrayList;
import java.util.List;

@RestController
@RequestMapping("/api/trucks/TrucksMarketApi")
public class TrucksMarketApi {

    private List<ITruck> MarketRepo;
    private ITruck ConcreteTruck;

        @Autowired
        public TrucksMarketApi(TrucksMarket trucksMarket){


        }

        public ITruck getByTypeMethod(String truckType)
        {
            if (truckType.contentEquals("tiltTruck")){
            ConcreteTruck = MarketRepo.get(0);}
            else if (truckType.contentEquals("standardTruck")){
            ConcreteTruck = MarketRepo.get(1);}
            else if (truckType.contentEquals("setTruck")){
            ConcreteTruck =  MarketRepo.get(2);}
            else if (truckType.contentEquals("tankTruck")){
            ConcreteTruck = MarketRepo.get(3);}
            else if (truckType.contentEquals("tipperTruck")){
            ConcreteTruck = MarketRepo.get(4);}

            return ConcreteTruck;
        }




    @GetMapping("/all")
    public List<ITruck> getAll() {
        return MarketRepo;
    }

    @GetMapping
    public ITruck getByType(@RequestParam String truckType){

        return  getByTypeMethod(truckType);
    }




}
