package pl.stp94.truckforwarder.models.player;

import org.springframework.stereotype.Repository;
import pl.stp94.truckforwarder.interfaces.ITruck;
import pl.stp94.truckforwarder.models.market.TrucksMarket;

import java.util.ArrayList;
import java.util.List;


@Repository
public class ActiveTrucks {



}
