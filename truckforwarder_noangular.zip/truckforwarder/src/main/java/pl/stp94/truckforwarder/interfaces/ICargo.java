package pl.stp94.truckforwarder.interfaces;

public interface ICargo {

    public String getType();
    public double getSize();





}
